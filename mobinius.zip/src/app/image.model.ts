export class image{
farm: number;
has_comment: number;
id: string;
is_primary: number;
isfamily: number;
isfriend: number;
ispublic: number
owner: string;
secret: string;
server: string
title: string;
}